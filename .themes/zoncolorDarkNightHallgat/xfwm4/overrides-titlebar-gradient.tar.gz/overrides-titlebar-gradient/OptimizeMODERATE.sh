#!/bin/bash

zcFP=$(cd "${0%/*}" && pwd); cd "$zcFP";

# Optimized for MODERATE_colored active top frame

cp -f --remove-destination OptimizeMODERATE_title-active.png title-1-active.png
cp -f --remove-destination OptimizeMODERATE_title-active.png title-2-active.png
cp -f --remove-destination OptimizeMODERATE_title-active.png title-3-active.png
cp -f --remove-destination OptimizeMODERATE_title-active.png title-4-active.png
cp -f --remove-destination OptimizeMODERATE_title-active.png title-5-active.png
cp -f --remove-destination OptimizeMODERATE_top-left-active.png top-left-active.png
cp -f --remove-destination OptimizeMODERATE_top-right-active.png top-right-active.png
cp -f --remove-destination OptimizeDARKLIGHTMODERATE_title-inactive.png title-1-inactive.png
cp -f --remove-destination OptimizeDARKLIGHTMODERATE_title-inactive.png title-2-inactive.png
cp -f --remove-destination OptimizeDARKLIGHTMODERATE_title-inactive.png title-3-inactive.png
cp -f --remove-destination OptimizeDARKLIGHTMODERATE_title-inactive.png title-4-inactive.png
cp -f --remove-destination OptimizeDARKLIGHTMODERATE_title-inactive.png title-5-inactive.png
cp -f --remove-destination OptimizeDARKLIGHTMODERATE_top-left-inactive.png top-left-inactive.png
cp -f --remove-destination OptimizeDARKLIGHTMODERATE_top-right-inactive.png top-right-inactive.png

exit
